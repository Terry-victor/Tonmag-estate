(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_Tonmag_Tonmag-estate_d6e81051._.js",
  "static/chunks/8bb76_749a983e._.js"
],
    source: "dynamic"
});
