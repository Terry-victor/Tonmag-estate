(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/8bb76_16913089._.js",
  "static/chunks/Desktop_Tonmag_Tonmag-estate_4f7456bc._.js"
],
    source: "dynamic"
});
