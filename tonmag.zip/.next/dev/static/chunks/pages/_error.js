__turbopack_load_page_chunks__("/_error", [
  "static/chunks/8bb76_next_dist_compiled_fb3364d2._.js",
  "static/chunks/8bb76_next_dist_shared_lib_a456ff9f._.js",
  "static/chunks/8bb76_next_dist_client_098ebfec._.js",
  "static/chunks/8bb76_next_dist_8b426ad4._.js",
  "static/chunks/8bb76_next_error_695744f9.js",
  "static/chunks/[next]_entry_page-loader_ts_4803f7b1._.js",
  "static/chunks/8bb76_react-dom_497c3729._.js",
  "static/chunks/8bb76_17d0483c._.js",
  "static/chunks/[root-of-the-server]__20b0182a._.js",
  "static/chunks/Desktop_Tonmag_Tonmag-estate_pages__error_2da965e7._.js",
  "static/chunks/turbopack-Desktop_Tonmag_Tonmag-estate_pages__error_c0fe3fc6._.js"
])
