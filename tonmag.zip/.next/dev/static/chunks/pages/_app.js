__turbopack_load_page_chunks__("/_app", [
  "static/chunks/8bb76_next_dist_compiled_fb3364d2._.js",
  "static/chunks/8bb76_next_dist_shared_lib_451ba4c8._.js",
  "static/chunks/8bb76_next_dist_client_098ebfec._.js",
  "static/chunks/8bb76_next_dist_08f115c1._.js",
  "static/chunks/8bb76_next_app_6e0d279f.js",
  "static/chunks/[next]_entry_page-loader_ts_6f86335a._.js",
  "static/chunks/8bb76_react-dom_497c3729._.js",
  "static/chunks/8bb76_17d0483c._.js",
  "static/chunks/[root-of-the-server]__532e29ef._.js",
  "static/chunks/Desktop_Tonmag_Tonmag-estate_pages__app_2da965e7._.js",
  "static/chunks/turbopack-Desktop_Tonmag_Tonmag-estate_pages__app_b0a521f9._.js"
])
