(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_Tonmag_Tonmag-estate_0ee37aad._.js",
  "static/chunks/8bb76_8327b456._.js"
],
    source: "dynamic"
});
