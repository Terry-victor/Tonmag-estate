(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_Tonmag_Tonmag-estate_4d903516._.js",
  "static/chunks/8bb76_@firebase_firestore_dist_index_esm_e192fb9a.js",
  "static/chunks/8bb76_43bdd71b._.js"
],
    source: "dynamic"
});
