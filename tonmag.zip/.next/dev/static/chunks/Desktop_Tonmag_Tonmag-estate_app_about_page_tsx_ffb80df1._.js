(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/8bb76_0961b55f._.js",
  "static/chunks/Desktop_Tonmag_Tonmag-estate_ede9899f._.js"
],
    source: "dynamic"
});
