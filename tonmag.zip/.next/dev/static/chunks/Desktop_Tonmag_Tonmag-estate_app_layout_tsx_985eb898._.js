(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_Tonmag_Tonmag-estate_8f217708._.js",
  "static/chunks/[root-of-the-server]__0afad0cd._.css"
],
    source: "dynamic"
});
