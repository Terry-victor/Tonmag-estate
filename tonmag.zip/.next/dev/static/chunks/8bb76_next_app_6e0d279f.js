(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/app.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/dist/pages/_app.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=8bb76_next_app_6e0d279f.js.map