globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/8bb76_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b42bb3a4._.js",
    "static/chunks/8bb76_next_dist_compiled_react-dom_33e0c296._.js",
    "static/chunks/8bb76_next_dist_compiled_react-server-dom-turbopack_77a0c6c1._.js",
    "static/chunks/8bb76_next_dist_compiled_next-devtools_index_7af1581b.js",
    "static/chunks/8bb76_next_dist_compiled_9cd97902._.js",
    "static/chunks/8bb76_next_dist_client_987fdc56._.js",
    "static/chunks/8bb76_next_dist_05ff6033._.js",
    "static/chunks/8bb76_@swc_helpers_cjs_9cc720f3._.js",
    "static/chunks/Desktop_Tonmag_Tonmag-estate_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_Tonmag_Tonmag-estate_b045ce8e._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];