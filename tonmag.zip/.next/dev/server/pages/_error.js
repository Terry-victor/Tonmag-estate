var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/8bb76_348bd0f4._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/8bb76_260aaf46._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/8bb76_next_72da63bf._.js")
R.m("[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/Tonmag/Tonmag-estate/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
