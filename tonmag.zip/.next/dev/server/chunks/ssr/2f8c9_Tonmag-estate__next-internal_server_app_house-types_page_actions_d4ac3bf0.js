module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/house-types/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2f8c9_Tonmag-estate__next-internal_server_app_house-types_page_actions_d4ac3bf0.js.map