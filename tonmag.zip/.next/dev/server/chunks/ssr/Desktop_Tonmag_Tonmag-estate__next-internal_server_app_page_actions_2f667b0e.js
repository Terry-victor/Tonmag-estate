module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_Tonmag_Tonmag-estate__next-internal_server_app_page_actions_2f667b0e.js.map