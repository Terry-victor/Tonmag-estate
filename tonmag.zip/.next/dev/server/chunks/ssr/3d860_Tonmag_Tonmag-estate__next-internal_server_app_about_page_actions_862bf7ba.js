module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/about/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_Tonmag_Tonmag-estate__next-internal_server_app_about_page_actions_862bf7ba.js.map