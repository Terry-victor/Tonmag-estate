module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/investment-plans/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2f8c9_Tonmag-estate__next-internal_server_app_investment-plans_page_actions_55235236.js.map