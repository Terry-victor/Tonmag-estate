module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/search/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_Tonmag_Tonmag-estate__next-internal_server_app_search_page_actions_275cdda3.js.map