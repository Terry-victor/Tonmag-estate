module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_Tonmag_Tonmag-estate__next-internal_server_app__not-found_page_actions_21333e92.js.map