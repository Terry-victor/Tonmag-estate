module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/credibility-legal/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2f8c9_Tonmag-estate__next-internal_server_app_credibility-legal_page_actions_c7d54b71.js.map