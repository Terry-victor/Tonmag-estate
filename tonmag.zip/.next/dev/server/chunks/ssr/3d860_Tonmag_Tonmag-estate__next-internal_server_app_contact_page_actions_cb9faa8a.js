module.exports = [
"[project]/Desktop/Tonmag/Tonmag-estate/.next-internal/server/app/contact/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_Tonmag_Tonmag-estate__next-internal_server_app_contact_page_actions_cb9faa8a.js.map